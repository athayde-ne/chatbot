from django.apps import AppConfig


class CapturasConfig(AppConfig):
    name = 'capturas'
