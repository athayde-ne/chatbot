from django.apps import AppConfig


class PerguntasConfig(AppConfig):
    name = 'perguntas'
